'use strict';

window.onload = function () {
    let currentImage = 1;
    const nDivSprite = document.getElementById('tDivSprite');

    const interval = setInterval(changeFrame, 250);

    function changeFrame() {
        switch (currentImage) {
            case 1:
                nDivSprite.classList.remove('frame-one'); // toggle 
                nDivSprite.classList.add('frame-two');
                currentImage = 2;
                break;
            case 2:
                nDivSprite.classList.remove('frame-two');
                nDivSprite.classList.add('frame-three');
                currentImage = 3;
                break;
            case 3:
                nDivSprite.classList.remove('frame-three');
                nDivSprite.classList.add('frame-one');
                currentImage = 1;
                break;
        }
    }

    const nDivButtonDestroy = document.getElementById('tDivButtonDestroy');
    nDivButtonDestroy.onclick = function () {
        clearInterval(interval);
        nDivSprite.classList.remove('frame-one');
        nDivSprite.classList.remove('frame-two');
        nDivSprite.classList.remove('frame-three');
        nDivSprite.classList.add('frame-four');
    }
}

