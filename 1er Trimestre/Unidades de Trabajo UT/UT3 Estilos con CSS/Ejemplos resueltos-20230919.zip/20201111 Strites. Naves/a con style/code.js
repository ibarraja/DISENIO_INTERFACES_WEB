'use strict';

window.onload = function () {
    let currentImage = 1;
    const nDivSprite = document.getElementById('tDivSprite');

    const interval = setInterval(changeFrame, 250);

    function changeFrame() {
        switch (currentImage) {
            case 1:
                nDivSprite.style.backgroundPosition = '0px 0px';
                currentImage = 2;
                break;
            case 2:
                nDivSprite.style.backgroundPosition = '0px calc(-1 * var(--sprite-width))';
                currentImage = 3;
                break;
            case 3:
                nDivSprite.style.backgroundPosition = '0px calc(-2 * var(--sprite-width))';
                currentImage = 1;
                break;
        }
    }

    const nDivButtonDestroy = document.getElementById('tDivButtonDestroy');
    nDivButtonDestroy.onclick = function () {
        clearInterval(interval);
        nDivSprite.style.backgroundPosition = '0px calc(-3 * var(--sprite-width))';
    }
}

