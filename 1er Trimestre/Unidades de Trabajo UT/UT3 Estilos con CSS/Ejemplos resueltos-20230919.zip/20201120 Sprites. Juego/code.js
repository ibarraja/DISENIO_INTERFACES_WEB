'use strict';

window.onload = function () {
    //goToSceneGame();
    //tButEnter.click(); //Operación click por software

    //Programamos los cursores
    document.onkeydown = moveBoy;
    activateMovementBoy();
}

let currentBoy = 0;
function activateMovementBoy() {
    setInterval(function () {
        currentBoy = (currentBoy === 11 ? 0 : currentBoy + 1);
        const nDivBoy = document.querySelector('.sprite-boy');
        const widthBoy = 2048 / 12;
        nDivBoy.style.backgroundPositionX = `${-1 * widthBoy * currentBoy}px`;
    }, 100);
}

function goToSceneGame() {
    const nSceneWellcome = document.querySelector('.scene-wellcome');
    // nSceneWellcome.style.display = 'none';
    //nSceneWellcome.classList.toggle('visible');
    nSceneWellcome.dataset.visible = 'false';

    const nSceneGame = document.querySelector('.scene-game');
    // nSceneGame.style.display = 'block';
    //nSceneGame.classList.toggle('visible');
    nSceneGame.dataset.visible = 'true';
}

const LEFT_CURSOR = 37;
const RIGHT_CURSOR = 39;
const UP_CURSOR = 38;
const DOWN_CURSOR = 40;

function moveBoy(e) {
    const pressedKey = e.keyCode;
    const nDivBoy = document.querySelector('.sprite-boy');

    switch (pressedKey) {
        case LEFT_CURSOR:
            nDivBoy.style.left = `${nDivBoy.offsetLeft - 10}px`;
            nDivBoy.style.transform = 'scale(0.5) rotateY(180deg)';
            break;
        case RIGHT_CURSOR:
            nDivBoy.style.left = `${nDivBoy.offsetLeft + 10}px`;
            nDivBoy.style.transform = 'scale(0.5) rotateY(0deg)';
            break;
        case UP_CURSOR:
            nDivBoy.style.top = `${nDivBoy.offsetTop - 10}px`;
            break;
        case DOWN_CURSOR:
            nDivBoy.style.top = `${nDivBoy.offsetTop + 10}px`;
            break;
    }
}