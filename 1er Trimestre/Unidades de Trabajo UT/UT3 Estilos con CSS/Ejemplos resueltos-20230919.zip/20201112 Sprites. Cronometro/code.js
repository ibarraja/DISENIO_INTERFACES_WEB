'use strict';

window.onload = startChronometer;

function startChronometer() {
    // const nDiv = document.getElementById('tDivChronometer');
    // nDiv.style.backgroundPositionX = '-500px';

    //tDivChronometer.style.backgroundPositionX = '-500px';

    //const nDiv = document.querySelectorAll('.sprite-numero');

    let positionX = (900 / 10) * -9;

    //Toda función que se pasa como argumento se llama callback.
    //Toda función que recibe como argumento una función o devuelve una función
    //se lla función de orden superior (first class function)
    const intervalId = setInterval(moveNumber, 100);

    //Clausura - closure
    function moveNumber() {
        const nDiv = document.querySelector('.sprite-numero');
        nDiv.style.backgroundPositionX = `${positionX}px`;
        positionX += 9;

        if (positionX > 0) {
            clearInterval(intervalId);
        }
    }
}
